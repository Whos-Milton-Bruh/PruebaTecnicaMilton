# TaskFlow – Gestor Diario de Tareas

Aplicación web para gestionar tareas diarias de forma visual e intuitiva.

## Funcionalidades
- Agregar tareas
- Marcar como completadas
- Eliminar tareas
- Guardado en localStorage
- Contador de tareas pendientes

## Tecnologías
- HTML5
- CSS3
- JavaScript Vanilla
- Git / GitHub

## Uso
Abrir el archivo index.html en el navegador.
